export const urlsAvailable = ['/flagging_history', '/deputy', '/stats']

export const querys = ['search_query']